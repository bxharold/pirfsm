import os
from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.security import check_password_hash, generate_password_hash
from helpers import apology, login_required, lookup, usd
import sqlite3, re, datetime                            
from sqlite3 import Error                 

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")

def create_connection(db_file): 
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)
    return conn

@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

@app.route("/home")
@login_required
def home():
    return redirect("/") 

@app.route("/")
@login_required
def index():
    rows = db.execute("SELECT symbol, stockname, shares FROM holdings where userid = ?", session["user_id"] )
    rowsB = []
    stockvalue=0
    for row in rows:
        json = lookup(row['symbol'])
        print(json)
        print(json['price'])
        print(json['price'] * row['shares'])
        row['price'] = json['price']             # added | usd in home.html
        row['curvalue'] = json['price'] * row['shares']
        stockvalue += row['curvalue'] 
        rowsB.append(row)
        # rv = db.execute("select count(*) as co from txns where userid = ? and id > ?", session['user_id'], 30)
        # print("rv=", rv)   #     rv= [{'co': 8}]
        # border cases:  45|4|C|SELL|1|44.26|Sat Dec 24 09:45:25 2022
        # rv = db.execute("select symbol as co from txns where id = ? and buysell = ?", 45, "SELL")
        # print("rv=", rv)   #     rv= [{'co': 8}]
        # rv = db.execute("select symbol as co from txns where id = ? and buysell = ?", 45, "BUY")
        # print("rv=", rv)   #     rv= []   # rv = None
    cashbalance =  cashAvailable(session["user_id"])
    # stockvalue is computed in the row loop
    grandtotal = cashbalance + stockvalue
    return render_template("home.html", rows=rowsB, cashbalance=cashbalance, stockvalue=stockvalue, grandtotal=grandtotal) 

# def index_old():
#     dbconn = create_connection("finance.db")  # hrf
#     cur = dbconn.cursor()
#     print("session user_id", str(session["user_id"]) )
#     cur.execute("SELECT symbol, stockname, shares FROM holdings where userid = ?", (str(session["user_id"]),) )
#     rows = cur.fetchall()
#     print("---",type(rows))    # list of dicts
#     rowsB = []
#     for row in rows:   
#         print(row, type(row), row)   # row is a tuple; use + (x,) to append. The , is needed.
#         json = lookup(row['symbol'])
#         print(json)
#         print(json['price'])
#         print(json['price'] * row[2])
#         row['price'] = json['price']
#         row['curvalue'] = json['price'] * row['shares']
#         rowsB.append(row)
#     return render_template("home.html", rows=rowsB) 

# # gotta figure out the new idiom.
# # rv = db.execute("select count(*) as co from txns where userid = ? and id > ?", session['user_id'], 30)
# # print("rv=", rv)   #     rv= [{'co': 8}]   so the value is rv[0]['co']   r0[0]['r00']
#              #     syntax:  [on_true] if [expression] else [on_false] 
# Example:
# #  stockid = getRow1Col( f"select id from holdings where userid='{suid}' and symbol='{symbol}'")
# r0 = db.execute("select id as r00 from holdings where userid=? and symbol=?", suid, symbol)
# stockid = "" if len(r0)==0 else r0[0]['r00']

# def getRow1Col(sql):  #####  don't use this.  
#     dbconn = create_connection("finance.db") 
#     cur = dbconn.cursor()
#     cur.execute(sql)
#     rows = cur.fetchall()
#     if len(rows)>0:
#         print( f"getrow:{sql}==={rows[0]}==={rows[0][0]}===")
#         return rows[0][0]
#     else:
#         return ""


def positiveInteger(x):
    match = re.search("^\d+$", x)
    if match is None:
        return False
    else:
        return int(x) != 0

def cashAvailable(userid):
    # cashavail = getRow1Col( f"select cash from users where id='{userid}'")
    r0 = db.execute("select cash as r00 from users where id= ?", userid)
    cashavail = r0[0]['r00']
    return cashavail

@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    if request.method == 'POST':
        symbol = request.form['symbol'].upper()
        shares = request.form['shares']
        if not positiveInteger(shares):
            return apology("Shares must be >= 0")
        else:
            shares = int(shares)
        json = lookup(symbol) 
        if json is None:
            return apology("Symbol Not Found")
        stockname = json['name']
        price = json['price']
        price = float(price)
        suid = str(session['user_id'])
        txdate = datetime.datetime.now().strftime("%c")
        print(suid, symbol, shares, price, stockname, txdate)

        cashavail = cashAvailable(suid)
        if cashavail < shares * price:
            return apology ("Insufficient funds")

        sqlnamed  = "insert into txns (buysell,userid,symbol,shares,price,txdate) "
        sqlnamed += "values ('BUY', :userid, :symbol, :shares, :price, :txdate)"
        valuesnamed = {'userid': suid, 'symbol': symbol, 'shares': shares, 'price': price, 'txdate': txdate}
        print(sqlnamed)

        dbconn = create_connection("finance.db")  
        dbconn.execute(sqlnamed, valuesnamed)
        dbconn.commit()

        #  Insert into holdings table if user already owns some of this stock, 
        #  else update; add shares to holdings.shares
        #  stockid = getRow1Col( f"select id from holdings where userid='{suid}' and symbol='{symbol}'")
        r0 = db.execute("select id as r00 from holdings where userid=? and symbol=?", suid, symbol)
        stockid = "" if len(r0)==0 else r0[0]['r00']
        if stockid == "":
            # new stock
            sqlnamed  = "insert into holdings (userid, symbol, stockname, shares) "
            sqlnamed += "values (:userid, :symbol, :stockname, :shares )"
            valuesnamed = {'userid': suid, 'symbol': symbol, 'shares': shares, 'price': price, 'stockname': stockname }
            dbconn.execute(sqlnamed, valuesnamed)
            dbconn.commit()
        else:
            # oldshares = getRow1Col( f"select shares from holdings where userid={suid} and symbol='{symbol}'")
            r0 = db.execute("select shares from holdings where userid=? and symbol=?", suid, symbol)
            oldshares = "" if len(r0)==0 else r0[0]['r00']
            newshares = int(shares) + int(oldshares)
            sqlnamed = f"update holdings set shares={newshares} where id={stockid}"
            dbconn.execute(sqlnamed)
            dbconn.commit()

        # update users table -- decrease cash by shares * price
        newcash = cashavail - shares * price
        # sqlnamed = f"update users set cash = '{newcash}' where id = {suid}"
        sqlnamed = "update users set cash = ? where id = ?"
        dbconn.execute(sqlnamed, newcash, suid )
        dbconn.commit()
        return redirect("/")
    else:
        return render_template("buy.html")

@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""
    if request.method == 'POST':
        symbol = request.form['symbol'].upper()
        shares = request.form['shares']
        if not positiveInteger(shares):
            return apology("Shares must be >= 0")
        else:
            shares = int(shares)
        json = lookup(symbol) 
        if json is None:
            return apology("Symbol Not Found")
        stockname = json['name']
        price = json['price']
        price = float(price)
        suid = str(session['user_id'])
        txdate = datetime.datetime.now().strftime("%c")
        print(suid, symbol, shares, price, stockname, txdate)

        cashavail = cashAvailable(suid)
        sqlnamed  = "insert into txns (buysell,userid,symbol,shares,price,txdate) "
        sqlnamed += "values ('SELL', :userid, :symbol, :shares, :price, :txdate)"
        valuesnamed = {'userid': suid, 'symbol': symbol, 'shares': shares, 'price': price, 'txdate': txdate}
        print(sqlnamed)

        dbconn = create_connection("finance.db")  
        dbconn.execute(sqlnamed, valuesnamed)
        dbconn.commit()

        #  update holdings table if user owns enough of this stock, 
        #  else update; add shares to holdings.shares
        #  stockid = getRow1Col( f"select id from holdings where userid='{suid}' and symbol='{symbol}'")
        r0 = db.execute("select id as r00 from holdings where userid=? and symbol=?", suid, symbol)
        stockid = "" if len(r0)==0 else r0[0]['r00']
        if stockid == "":
            return apology("Symbol Not Found")
        # sharesowned = getRow1Col( f"select shares as r00 from holdings where userid='{suid}' and symbol='{symbol}'")
        r0 = db.execute( "select shares as r00 from holdings where userid=? and symbol=?", suid, symbol)
        sharesowned = r0[0]['r00']
        if sharesowned < shares:
            return apology("Insufficient Shares")
        # update holdings table -- subtract shares
        newshares = int(sharesowned) - int(shares)
        if newshares > 0:   
            # sqlnamed = f"update holdings set shares={newshares} where id={stockid}"
            sqlnamed = "update holdings set shares=? where id=?"
            dbconn.execute(sqlnamed, newshares, stockid)
        else:
            # sqlnamed = f"delete from holdings where id={stockid}"
            sqlnamed = f"delete from holdings where id=?"
            dbconn.execute(sqlnamed, stockid)
        dbconn.commit()

        # update users table -- increase cash by shares * price
        newcash = cashavail + shares * price
        sqlnamed = f"update users set cash = '{newcash}' where id = {suid}"
        dbconn.execute(sqlnamed)
        dbconn.commit()
        return redirect("/")

    else:
        return render_template("sell.html")

@app.route("/history")
@login_required
def history_new():
    qry = "SELECT userid, txdate, symbol, buysell, shares, price from txns where userid = ? order by id desc"  
    rows = db.execute(qry, str(session['user_id']) )
    return render_template("history.html", rows=rows)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""
    # Forget any user_id
    session.clear()
    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)
        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)
        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = ?", request.form.get("username"))
        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)
        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]
        session["user_name"] = rows[0]["username"]
        return redirect("/")
    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    # Forget any user_id
    session.clear()
    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    if request.method == "POST":
        ticker = request.form.get('ticker')
        msg = ""
        ok = True
        if ok and (len(ticker)  == 0):
            msg += "Required field left blank. Specify a ticker symbol. "
            ok = False
        if ok and len(ticker) > 10:
            msg += "max ticker length is 10.  "
            ok = False
        if ok and not goodChars(ticker):
            msg += "Invalid characters in ticker symbol. "
            ok = False
        json = ""
        if not ok:
            return render_template("quote.html", msg=msg, json="")
        else:   
            json = lookup(ticker)
            if json is None:
                return apology("Symbol Not Found")
            else:
                json['datm'] = datetime.datetime.now().strftime("%c")
                return render_template("quote.html", msg=msg, json=json)
    else:
        return render_template("quote.html", msg="", json="JSON")


def goodChars(x):   # returns True if no naughty chars
    # "R2-D2" and "Lady-Gaga" are OK; "Thurston Powell III" is not.
    match = re.search(r"[^\dA-Za-z\-]", x)
    if match is None:
        return True
    else:
        return False

@app.route("/register", methods=["GET", "POST"])
def register():
    #  CHANGE NEEDED:  use apology to exit, not ok and ... msg +=
    #  db.execute needs qmark params, not named
    if request.method == "POST":
        username = request.form.get('username')
        password = request.form.get('password')
        confirmation = request.form.get('confirmation')
        if password != confirmation:
            return apology("Passwords do not match")
        if len(username) * len(password) == 0:
            return apology("Required field left blank")
        if len(username) > 20:
            return apology("Name should be at most 20 chars.")
        if not goodChars(username):
            return apology("Invalid characters in name.")
        #  -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   - 
        #  db.execute needs qmark params, not named
        rv = db.execute("select count(*) as co from users where username like ?", username)
        if rv[0]["co"] != 0:
            return apology("Username Already Exists")
        #  -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   
        # if we get this far, hash the pw, make the table entry.
        try:
            hash = generate_password_hash(password)  
            sqlqmark = "insert into users (username,hash) values (?,?)"
            num = db.execute(sqlqmark, username, hash)
        except:
            return apology("Registration failed.")
        if num > 0:
            return render_template("regsucc.html", username=username)  
        else:
            pass          
    else:
        return render_template("register.html")

def main():
    app.run(debug=True)

if __name__ == '__main__':
    main()
#              #     syntax:  [on_true] if [expression] else [on_false] 
