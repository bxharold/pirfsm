#!/usr/bin/python3 
#   wybcmd.py  6/14/2022 for bottle ycam; was webcmd.py for php birdicam
#   run this on mc21a:  pi@mc21a:~/py/ycam/webcmd.py &
#   access from sd128a: http://192.168.1.29:8080/?command=R
   
from bottle import route, run, template, request, debug
from gpiozero import LED, Servo, Button
import os, subprocess, time, json
ledb = LED(13)
ledy = LED(19)
ledr = LED(26)
button = Button(6)
servo = Servo(4)     # was 2, changed 4/18/2022
servo.min(); print(servo.value)
servo.max(); print(servo.value)
servo.mid(); print(servo.value)
delta = 0.2  # for servo
servoValue = 0
servoCommandList = ['BL','BC','BR','BPL','BPS','BPR','DET']

def mkjson(name,value):
    d = {}
    d["name"] = name
    d["value"] = value
    dj = json.dumps(d)
    return dj

# Handler for the home page
@route('/') 
def index():
    global servoValue
    cmd = request.GET.get('command', '')
    if cmd in servoCommandList:
        print(f"              =_= Servo:  {servoValue:0.3f}", end="")
        if cmd == 'BL':
            servoValue = max(-1,servoValue - delta)
            servo.value = servoValue
            print(f" ===> {servoValue:0.3f}")
            time.sleep(0.5)
            servo.detach()   # value is null
            return 'mySERVO('+mkjson("BL servo left", servoValue)+')'
        elif cmd == 'BC':
            servo.mid()
            servoValue = 0
            print(f" ===> {servoValue:0.3f}")
            time.sleep(0.05)
            servo.detach()   # value is null
            return 'mySERVO('+mkjson("BC servo mid", servoValue)+')'
        elif cmd == 'BR':
            servoValue = min(1,servoValue + delta)
            servo.value = servoValue
            print(f" ===> {servoValue:0.3f}")
            time.sleep(0.05)
            servo.detach()   # value is null
            return 'mySERVO('+mkjson("BR servo right", servoValue)+')'
        elif cmd == 'BPL':
            sv = servoValue
            print(f" BPL ======> {servoValue:0.3f}")
            svds = 0.1
            while sv > -1:
                servo.value = sv
                time.sleep(0.05)
                servo.detach()
                print(f" sv ===> {sv:0.3f}")
                sv = sv - svds
                time.sleep(0.5)
            servo.value =  -1
            servoValue = servo.value
            time.sleep(0.05)
            servo.detach()   # value is null
            return 'mySERVO('+mkjson("BPL servo min", servoValue)+')'
        elif cmd == 'BPS':
            #servoValue = servo.value
            servo.detach()   # value is null
            print(f" ===> {servoValue:0.3f}")
            return 'mySERVO('+mkjson("BPS servo detach", servoValue)+')'
        elif cmd == 'BPR':
            sv = servoValue
            print(f" BPR ======> {servoValue:0.3f}")
            svds = 0.1
            while sv < 1:
                servo.value = sv
                time.sleep(0.05)
                servo.detach()
                print(f" sv ===> {sv:0.3f}")
                sv = sv + svds
                time.sleep(0.5)
            servo.value =  1
            servoValue = servo.value
            time.sleep(0.05)
            servo.detach()   # value is null
            return 'mySERVO('+mkjson("BPR servo max", servoValue)+')'
        elif cmd == 'DET':
            servoValue = servo.value
            servo.detach()   # value is null
            print(f" ===> {servoValue:0.3f}")
            return 'mySERVO('+mkjson("DET servo detach", servoValue)+')'
    else:      #  decouple servo, LED
        if cmd == 'R':
            ledr.on()
            return 'myLED({"name": "RedBird", "value": "R"})'
        elif cmd == 'r':
            ledr.off()
            return 'myLED({"name": "notRedBird", "value": "r"})'
        elif cmd == 'Y':
            ledy.on()
            return 'myLED({"name": "YellowBird", "value": "Y"})'
        elif cmd == 'y':
            ledy.off()
            return 'myLED({"name": "notYellowBird", "value": "y"})'
        elif cmd == 'B':
            ledb.on()
            return 'myLED({"name": "BlueThonnyBird", "value": "B"})'
        elif cmd == 'b':
            ledb.off()
            return 'myLED({"name": "notBlueBird", "value": "b"})'

    # Every command up until here has a return
    if cmd == 'K':  # Kill video stream. 
        sproc = os.popen( "ps -au | grep webstream | grep -v grep | cut -c9-15")
        stpid = sproc.read().strip()
        subprocess.run([f"kill {stpid}"], shell=True)
        
@route('/UTIL')
def index():
    uproc = bcamUTIL_py()
    ut = uproc.strip()
    return ut 

@route('/PID')
def index():
    uproc = bcamPID_py()
    ut = uproc.strip()
    return ut 

###   ----------------------------------------
def cpu_util():  
  cpu_util_cmd = "top -bn5 | head -3 | tail -1 | awk '{print 100-$8}'"
  dev = os.popen(cpu_util_cmd)
  cpu_util_raw = dev.read()
  return cpu_util_raw.strip() 

def cpu_temp():  
  dev = os.popen('/opt/vc/bin/vcgencmd measure_temp')
  cpu_temp_raw = dev.read()[5:-3]
  return cpu_temp_raw.strip()

def hostname():
  dev = os.popen("hostname")
  hn = dev.read()
  return hn.strip()

def timestamp():
  dev = os.popen("date +%T")
  ts = dev.read()
  return ts.strip()

def bcamUTIL_py():
    d = {}
    d["util"] = cpu_util() + " %"
    d["temp"] = cpu_temp() 
    d["hostname"] = hostname()
    d["timestamp"] = timestamp()
    cpuj = json.dumps(d)
    return "bcamUTILcallback("+cpuj+")"   

def pid(p):
    dev = os.popen(f"ps -au | grep {p} | grep -v grep | cut -c9-15")
    x = dev.read().strip()
    return x if x!="" else "-1"

def bcamPID_py():
  d = {}
  d["hostname"] = hostname()
  d["webstreamPID"] = pid("python3.*webstream")
  d["webcmdPID"] = pid("python3.*wybcmd")
  d["timestamp"] = timestamp()
  cpuj = json.dumps(d)
  return "bcamPIDcallback("+cpuj+")"   

### ---- Button -----------------------------
global b_t0, b_tf, b_downtime
b_t0, b_tf, b_downtime = 0,0,0
def buttonPressStart():
    global b_t0, b_downtime
    b_downtime = 0
    b_t0 = time.time()
    print(f'Button was pressed at {b_t0}')

def buttonReleased():
    global b_t0, b_tf, b_downtime
    b_tf = time.time()
    print(f'Button was released at {b_tf}, held for {b_tf-b_t0} secs')
    b_downtime = b_tf-b_t0
    b_t0, b_tf = 0,0
    if b_downtime > 1.2:
        print("LONG PRESS")
        ledy.toggle()
    elif b_downtime > 0.02:
        print("SHORT PRESS")
        ledr.toggle()

button.when_pressed = buttonPressStart
button.when_released = buttonReleased

try:
    bt = 0.1
    servoValue=0
    time.sleep(1); ledr.on();time.sleep(bt);ledy.on();time.sleep(bt);ledb.on();
    time.sleep(1);ledb.off();time.sleep(bt);ledy.off();time.sleep(bt);ledr.off(); 
    servo.detach()
    run(host="0.0.0.0", port=8080)

except KeyboardInterrupt:
    pass
finally:
    servo.min()
    servo.value = None
    print("\nOK, Done.")

