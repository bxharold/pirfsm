#!/usr/bin/python3
# pi@mc21a:~/py/ycam/ycam.py   # python port of jbframes.php    
# was developed in pi@mc21a:~/py/tests/mtbottle.py   
 
from bottle import route,run,template,request,static_file
import os

IP = os.popen("hostname -I").read().strip()
PORT = 8090   # the ycam.py port

M_frame = """
  <button id="bcamPID">PIDs (bcamPID) </button>
    <font size=2><span id="msgPID"> msgUTIL </span></font> 
  <BR><button id="bcamUtilTemp">mc21a (bcamUtilTemp) </button>
  <font size=2><span id="msgUTIL"> msgUTIL </span></font>
  <BR> <button id="bcamLocalUtilTemp">sd128a (bcamLocalUtilTemp) </button>
    <font size=2><span id="msgLocalUTILTemp"> msgLocalUTILTemp </span></font>
  <BR><em><font size=2>webcmd.py servo and LED callbacks:</em> <span id="msg">msg</span></font>
"""

V_frame = """
       <B><a href=http://192.168.1.8:8090> BirdieCam</a></B>
       &nbsp;&nbsp; Video http://mc21a:8000/ &nbsp;&nbsp; Running on port 8090/ &nbsp;&nbsp; Project: mc21a:~/py/ycam 
       <iframe src="http://192.168.1.8:8000/index.html" width=680 height=540 ></iframe>
<font size=2><em> If the video stream fails or freezes, check the Camera PID. If Camera PID>0, refresh this page. If "-1", start the camera server, then reload this page. If that fails, try " ps -aux | grep mjp  ", and kill the offending raspimjpeg process.
<BR> If Command PID is "-1", webcmd.py was probably started from an IDE like Thonny.</em></font>
"""

A_frame = """
<table border=0  ules=rows width=100% >
<TR><TH colspan=4 align=left>LEDs
<TR><TD width=80><input type=checkbox class="C" id="CBred" ></input><BR>Red
    <TD width=80><input type=checkbox class="C" id="CByellow" ></input><BR>Yellow
    <TD width=80><input type=checkbox class="C" id="CBblue" ></input><BR>Blue
    <TD width=120 align=right> <button id="LEDreset" class="B">Reset All </button>
<TR><TD><TD colspan=4 align=left> &nbsp; <span id="LEDmsg">&nbsp;</span>
</table>
"""

B_frame = """
<table border=0  ules=rows width=198>
<TR><TH colspan=3 align=left>Pan / Servo Control
<TR><TD colspan=3 align=left> &nbsp; Move:
<TR><TH width=90><button class="B" id="BL" > &#9665;&nbsp;Left </button>
    <TH width=90><button class="B" id="BC" > &gt;Center&lt; </button>
    <TH width=90><button class="B" id="BR" > Right &nbsp; &#9655;</button>
<TR><TD colspan=3 align=left> &nbsp; Pan:
<TR><TH><button class="B" id="BPL"> &#9664; </button>
    <TH><button class="B" id="BPS" > &#9724; </button>
    <TH><button class="B" id="BPR"> &#9654; </button>
<TR><TD colspan=3 align=left>&nbsp;
<TR><TD colspan=3 align=left>&nbsp;Bearing:
    <BR><center>
<canvas id="cBearing" width="200" height="120" style="border:1px solid #d3d3d3;">:(</canvas>
        </center>
<TR><TD>&nbsp;Status:<TD colspan=2 align=left> &nbsp; <span id="servomsg">Idle</span>
<TR><TH colspan=3 align=left><HR height=3>

<TR><TH colspan=3 align=left>Camera / Server
<TR><TD> &nbsp;Camera&nbsp;PID: <TD><div id="bcamwebstreamPID"> n/a </div>
<TD><button class="B" id="StopCamera">Stop Camera</button>
<TR><TD> &nbsp;Command&nbsp;PID: <TD><div id="bcamwebcmdPID"> n/a </div>
</table>
"""

C_frame = """
  <table border=0  ules=rows width=198>
    <TR><TH colspan=3 align=left >CPU Performance
    <TR><Td align=middle colspan=3>
           <table border=1 width=298 rules=rows cellspacing=9>
            <TR><Td width=98>Machine
                <Td width=98 align=right> Utilization
                <Td width=98>Temperature(&deg;C)
             <TR><Td width=98 align=left><div id="bcamHostname">cam&nbsp;server</div>
                <Td align=right width=98><div id="bcamUtil">util</div>
                <Td align=right width=98><div id="bcamTemp"> temp</div>
             <TR><Td width=98 align=left><div id="bcamHostname2">sd128a</div>
                <Td align=right width=98><div id="bcamUtil2">util2</div>
                <Td align=right width=98><div id="bcamTemp2"> temp2</div>
           </table>
        </Td>
    <TR><TH><button class="B" id="bUpdateCPU" onClick=
         '$("#bcamLocalUtilTemp").click(); $("#bcamUtilTemp").click();'>Update</button>
         <TH><button class="B" id="bLoopCPU" onClick='perfStartTimer()'> Loop... </button>
         <TH><button class="B" id="bStopLoopCPU"  onClick='perfStopTimer()'> Stop.</button>
  </table>
"""

@route('/')
@route('/<p>')
def index(p=""):
    param = 'friends' if p=="" else p
    return template('ycam', param=param, M_frame=M_frame, C_frame=C_frame, A_frame=A_frame, B_frame=B_frame, V_frame=V_frame, IP=IP, PORT=PORT)

@route('/static/<filename>')
def server_static(filename):
    return static_file(filename, root='./static')

if __name__ == '__main__':
    run(host="0.0.0.0", port=PORT, debug=True, reloader=False)

